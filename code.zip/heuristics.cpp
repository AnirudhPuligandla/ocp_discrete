#include "heuristics.h"

void Heuristics::greedyAlgo(QVector<QVector3D> &arrayControlCopy,
                            int nCam,
                            VisibilityCheck &visibilityObj,
                            QVector<QVector<int> > &camSolution,
                            QVector<int> &backSolution)
{
    // Copy of control point coordinates to keep track of covered control points
    QVector<QVector3D> backVoxels(arrayControlCopy);
    // Copies of camPos and normals vectors
    //QVector<QVector3D> boundVoxels(camPosVec);
    //QVector<QVector3D> boundNormals(camNormalsVec);

    int controlPoints = backVoxels.size();
    // Max number of cameras allowed
    //int nCam = 5;

    // number of control points covered
    //int nbCovered = 0;

    // Number of cameras placed
    int nCamPlaced = 0;

    // Stopping criteria (minimum required coverage)
    //int reqCoverage = (95 * controlPoints)/100;

    // Get the created gmatrix and selected indices
    boost::numeric::ublas::compressed_matrix<bool> gMatrix;
    QVector<QVector<int>> camIndices;
    visibilityObj.getMatrixAnd1D(gMatrix, camIndices);
    // A copy of indices vector, to make the indices match even after deletion from one
    QVector<QVector<int>> indicesUnaltered(camIndices);

    // Number of camera points
    int camPos = camIndices.size();

    // Intialize output containers for optimized camera positions and covered control points
    QVector<bool> c(controlPoints, 0);
    QVector<bool> var(camPos);
    for(int i = 0; i < camPos; i++)
    {
        var[i] = 0;
    }

    // Container to check for global camera positions
    QVector<int> globalPos(nCam);
    // int to hold global camera position
    int globalPos1;

    // Loop for algorithm
    while (/*nbCovered <= reqCoverage &&*/ nCamPlaced < nCam)
    {
        // create matrix to hold rank
        QVector<int> coverageRank(camPos);

        // Create rank matrix from g matrix
        for(int i = 0; i < camPos; i++)
        {
            int coverageCount = 0;
            for(int j = 0; j < controlPoints; j++)
            {
                coverageCount += gMatrix(i, j);
            }
            coverageRank[i] = coverageCount;
        }

        // -------------Search for highest rank-------------------------------
        int pos1 = 0, pos2 = 0;
        int maxRank = coverageRank[0];
        //QVector<QVector<int>>::iterator i = coverageRank.begin();           // Iterator over camera positions
        QVector<int>::iterator i = coverageRank.begin();
        while (i != coverageRank.end())
        {
            //QVector<int>::iterator j = i->begin();
            //while(j != i->end())
            //{
            if(*i > maxRank)
            {
                maxRank = *i;
                pos1 = std::distance(coverageRank.begin(), i);
                // pos2 = std::distance(i->begin(), j);
            }
            //j++;
            //}
            i++;
        }

        /* Keep track of camera location indices w.r.t 'boundVox'
         * as we are removing positions from it and it results in mismatch between the locations
         */
        globalPos[nCamPlaced] = pos1;
        globalPos1 = pos1;
        //qDebug()<< coverageRank[pos1];
        for(int camCounter = 0; camCounter < nCamPlaced; camCounter++)
        {
            // Check each camera position w.r.t. newly obtained camera locations
            if(globalPos[camCounter] <= pos1)
                globalPos1 += 1;
        }

        // Place a camera at the position and orientation with highest rank
        var[globalPos1] = 1;
        // Increment number of newly covered points
        //nbCovered += maxRank;
        // Increment number of cameras placed
        nCamPlaced++;

        // Vector to store indices of occupied control points by the placed camera
        //QVector<int> backOccupiedPoints;

        // Update control points variable with newly covered points
        for(int j = 0; j < controlPoints; j++)
        {
            if(gMatrix(pos1, j) == 1)
            {
                // Search for the index of this control point in the original copied array
                c[arrayControlCopy.indexOf(backVoxels[j])] = 1;
                /* mark coordinates in 'arrayControl' at these indices with the special value (-1, -1, -1).
                 * Any 'special values' with negative values should be safe as the voxel environment has
                 * only positive coordinates.
                 */
                backVoxels[j] = QVector3D(-1.0f, -1.0f, -1.0f);
                // save the index for later use
                //backOccupiedPoints.append(j);
            }
        }

        /* Remove covered control points from original list of control points
         * And update the number of uncovered points
         */
        int numBackRemove = backVoxels.removeAll(QVector3D(-1.0f, -1.0f, -1.0f));

        // Remove the value from the 1Dindices vector
        camIndices.erase(camIndices.begin() + pos1);
        camPos -= 1;
        // Adjust the controlPoints count
        controlPoints -= numBackRemove;

        if(nCamPlaced == nCam)
            continue;

        // setup g matrix with updated possible camera positions and uncovered control points
        //greedyOccupancy = VisibilityCheck(boundVoxels, boundNormals, backVoxels);
        // Recompute the gMatrix for now available points
        visibilityObj.getSolutionoccupation(camIndices, backVoxels, gMatrix);
    }

    // Save the camera locations solution
    //for(int k = 0; k < var.size(); k++)
    //{
    for (int i = 0; i < var.size(); i++)
    {
        if(var[i] == 1)
            camSolution.append(QVector<int>({indicesUnaltered[i][0], indicesUnaltered[i][1]}));
    }
    //}
    qDebug() << "Number of cameras placed with greedy algorithm = " << camSolution.size();
    // Save covered control points solution
    float coverageSum = 0;
    for (int i = 0; i < c.size(); i++)
    {
        if(c[i] == 1)
        {
            backSolution.append(i);
            coverageSum++;
        }
    }
    // Display coverage percentage
    qDebug() <<"Coverage % with greedy algorithm = " << (coverageSum/arrayControlCopy.size())*100;
}

void Heuristics::metroSA(int numControl,
                         int numCam, int numCamsRequired,
                         QVector<QVector<int>> &index1D,
                         boost::numeric::ublas::compressed_matrix<bool> &gMat2D,
                         QVector<QVector<int>> &camSolution,
                         QVector<int> &backSolution)
{
    // Let's say we want to place 5 cameras
    //int numCamsRequired = 5;
    // Container to hold randomly selected cameras
    QVector<int> cam;
    // Global solution containers
    int fCamPlace = 0;
    QVector<int> camPlace;

    /* Initialize the W vector. Since this vector is dynamic, it can be defined as vector
     * pointing to the indices in index1D vector. That way even when elements are removed
     * from W, we can still keep track of original camera indices
     */
    QVector<int> W(numCam);
    for(int i = 0; i < numCam; i++)
        W[i] = i;

    /* Generate 5 random numbers between 0 and index1D.size()
     * We also need to ensure they don't have the same position to satisfy the condition
     * of not placing more than one camera with different orientations at each position
     */
    int numCamRemaining = W.size();
    std::default_random_engine generator((int)QTime::currentTime().msec());
    std::uniform_int_distribution<int> distribution(0, numCam-1);
    while(cam.size() < numCamsRequired)
    {
        int randNum = distribution(generator);
        //qDebug() << randNum;
        // Check with previously added cam positions to see if we got new cam at same position but diff orientation
        bool camRepeat = 0;
        for(int i = 0; i < cam.size(); i++)
        {
            // Check position stored in index1D array
            if(index1D[cam[i]][0] == index1D[randNum][0])
                camRepeat = 1;
        }
        // select new random camera only if 'camRepeat' flag is false
        if(!camRepeat)
        {
            // Add the index in randNum into cam vector
            cam.append(W[randNum]);
            /* Use the same strategy as in greedy algorithm
             * Mark the elements with -1 and remove them all at once later
             */
            W[randNum] = -1;
        }
    }
    // Remove all previously marked elements from W
    numCamRemaining -= W.removeAll(-1);
    // Initiaize camPlace with cam to make we dont miss the case of initial random being best solution
    //camPlace = cam;

    /* Algorithm shows to run until N_c, but size of W is already less than N_c
     * That means we will run out of cameras in W before N_c iterations, so run until numCamRemaining
     */
    // Create a new random generator
    std::default_random_engine generator2((int)QTime::currentTime().msec());
    // distribution for selection from cam
    std::uniform_int_distribution<int> distribution2(0, cam.size()-1);
    // Stop when certain number of iterations are complete
    int numIter = 0;
    int maxIter = numCam;
    while((numCamRemaining > 0) && (numIter <= maxIter))
    {
        int bCam = distribution2(generator2);
        // distribution for selection from W
        std::uniform_int_distribution<int> distribution3(0, numCamRemaining-1);
        int cCam = distribution3(generator2);
        // Check if new cam has same position as any one of the 4 cams remaining
        bool camRepeat = 0;
        // Get actual camera index from remaining values in W vector
        int actualCamIndex = W[cCam];
        // get cam index from index1d array for cCam so that we dont have to go through array 4 times
        int newCamPosIndex = index1D[actualCamIndex][0];
        for(int i = 0; i < cam.size(); i++)
        {
            if(index1D[cam[i]][0] == newCamPosIndex)
                camRepeat = 1;
        }
        // if cCam camera position already exists, then just skip the loop
        if(!camRepeat)
        {
            // Create cam_dash with cam - bCam + cCam
            QVector<int> cam_dash = cam;

            // Construct cam_dash by replacing at index bCam with number in index cCam
            cam_dash[bCam] = W[cCam];
            /* Calculate coverage in terms total number points by each cam and cam_dash
             * summing up coverage by individual cameras results in lots of overlap
             */
            int fCam=0, fCam_dash=0;
            for(int j = 0; j < numControl; j++)
            {
                bool camCover = false, cam_dashCover = false;
                // Loop over the number of cameras
                for(int  i = 0; i < cam.size(); i++)
                {
                    camCover = camCover || gMat2D(cam[i], j);
                    cam_dashCover = cam_dashCover || gMat2D(cam_dash[i], j);
                }
                fCam += camCover;
                fCam_dash += cam_dashCover;
            }
            /*
            // -------calculate net coverage of both cam and cam'--------
            int fCam=0, fCam_dash=0, fBCam=0, fCCam=0;
            // first calculate for cam
            for(int i = 0; i < cam.size(); i++)
            {
                int fTemp = 0;
                // Calculate coverage for this camera by looping over number of control points
                for(int j = 0; j < numControl; j++)
                {
                    fTemp += gMat2D(cam[i], j);
                }
                // If this cam Position is same as bCam then also save it separately for later use
                if(i == bCam)
                    fBCam = fTemp;
                // Add the coverage value to fCam
                fCam += fTemp;
            }
            // Calculate coverage for cCam camera position
            for(int j = 0; j < numControl; j++)
                fCCam += gMat2D(actualCamIndex, j);
            // Construct fCam_dash = fCam - fBCam + fCCam
            fCam_dash = fCam - fBCam + fCCam;
            */
            // Calculate deltaH = fCam_dash/fCam
            double deltaH = double(fCam_dash)/double(fCam);
            // Draw a random number between (0,e)
            //std::uniform_real_distribution<double> distributionReal(1.0, exp(1.0)); // number 0 can cause pole error in log function
            std::uniform_real_distribution<double> distributionReal(0.0, 1.0);
            double uNum = distributionReal(generator2);
            // Check condition
            // variables for debugging
            double conditionNum1 = uNum;
            double conditionNum2 = deltaH < 1.0 ? deltaH : 1.0;
            if(conditionNum1 <= conditionNum2)
            {
                cam = cam_dash;
                if(fCam_dash > fCamPlace)
                {
                    // Set final values
                    fCamPlace = fCam_dash;
                    // setup final solution output
                    camPlace = cam_dash;
                }
            }
            // Remove cCam from W
            W.remove(cCam);
            numCamRemaining--;
        }
        // Increment number of iterations
        numIter++;
    }

    // vector to calculate total number of covered background points
    QVector<bool> backgroundCoverageVerify(numControl, 0);
    // Setup Final Solution
    for(int i = 0; i < camPlace.size(); i++)
    {
        int currCamIndex = camPlace[i];
        camSolution.append(QVector<int>({index1D[currCamIndex][0], index1D[currCamIndex][1]}));
        // Get indices of occupied points for this camera
        for(int j= 0; j < numControl; j++)
        {
            if(gMat2D(currCamIndex, j))
            {
                backSolution.append(j);
                // Set the background voxel with value 1
                backgroundCoverageVerify[j] = 1;
            }
        }
    }
    // Calculate the percentage of covered points
    float coverSum = 0.0;
    for(int i = 0; i < numControl; i++)
        coverSum += backgroundCoverageVerify[i];
    // Print result
    qDebug() << "Coverage % with Metropolis Algorithm = " << coverSum/numControl*100.0;
    qDebug() << "Number of cams placed = " << camSolution.size();
}
