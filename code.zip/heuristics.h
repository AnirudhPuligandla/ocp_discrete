#ifndef HEURISTICS_H
#define HEURISTICS_H

#include <string>
#include <math.h>
#include <iostream>
#include <vector>
#include <random>

#include <boost/numeric/ublas/matrix_sparse.hpp>
#include <boost/numeric/ublas/io.hpp>

#include <QVector>
#include <QVector3D>
#include <QDebug>
#include <QTime>

#include "visibilitycheck.h"

class Heuristics
{
public:
    /* Function for greedy heuristic algorithm
     * Inputs : controlPoints   -> control points vector
     *          camPos          -> camera locations vector
     *          camNormals      -> camera location (primary) normals vector
     *          visibilityObj   -> Object to visibility checks class that is currently initialized and used
     * Outputs: camSolution     -> output vector to store optimized camera locaiton indices
     *          backSolution    -> output vector to store occupied control points indices
     */
    void greedyAlgo(QVector<QVector3D> &arrayControlCopy,
                    int nCam,
                    VisibilityCheck &visibilityObj,
                    QVector<QVector<int> > &camSolution,
                    QVector<int> &backSolution);
    /* Function for Metropolis sampling algorithm for FIX problem
     * Inputs : controlPoints   -> number of control points
     *          camPos          -> number of camera positions x orientations
     *          numCamReq       -> number of cameras to be placed
     *          camIndice       -> 2D to 1D indices vector pointing to camera positions and orientations
     *          gMatrix         -> 2D visibility matrix with camera positions and orientations stacked together
     * Outputs: camSolution     -> output vector to store optimized camera locaiton indices
     *          backSolution    -> output vector to store occupied control points indices
     */
    void metroSA(int numControl,
                 int numCam,
                 int numCamsRequired,
                 QVector<QVector<int>> &index1D,
                 boost::numeric::ublas::compressed_matrix<bool> &gMat2D,
                 QVector<QVector<int> > &camSolution,
                 QVector<int> &backSolution);
};

#endif // HEURISTICS_H
